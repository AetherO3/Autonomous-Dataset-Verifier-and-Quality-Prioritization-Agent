import great_expectations as gx
import pandas as pd


def is_url_or_id_column(col: str, stats: dict) -> bool:
    name_hints = ("_id", "_link", "_url", "_uri", "_href", "_src")
    if any(col.lower().endswith(h) for h in name_hints):
        return True
    sample_vals = [str(v) for v in stats.get("sample", [])]
    if any(v.startswith("http") for v in sample_vals):
        return True
    return False


def detect_issues(profile: dict, df: pd.DataFrame) -> dict:
    context = gx.get_context(mode="ephemeral")
    datasource = context.data_sources.add_pandas("pandas_source")
    asset = datasource.add_dataframe_asset("dataset")
    batch = asset.add_batch_definition_whole_dataframe("batch").get_batch(
        batch_parameters={"dataframe": df}
    )

    issues = {}

    for col, stats in profile.items():
        col_issues = []

        if stats["null_perc"] > 0.3:
            result = batch.expect_column_values_to_not_be_null(column = col)
            if not result.success:
                col_issues.append("high_missing")

        if stats["unique"] == 1:
            col_issues.append("constant_column")
        elif ( stats["column_type"] == "numeric" and stats["std"] is not None and stats["std"] < 1e-3):
            col_issues.append("near_constant")

        if (
            stats["unique_ratio"] >= 0.9
            and stats["column_type"] not in ("datetime", "numeric")
            and is_url_or_id_column(col, stats)
        ):
            col_issues.append("id_like_column")

        elif (
            stats["unique_ratio"] > 0.9
            and stats["column_type"] not in ("datetime", "numeric")
        ):
            col_issues.append("high_cardinality")

        if stats["column_type"] == "nested":
            col_issues.append("nested_data")

        if stats["column_type"] == "numeric":
            if stats.get("skewness") and abs(stats["skewness"]) > 2:
                col_issues.append("high_skewness")
            if stats.get("n_zeros") and stats["count"] and stats["n_zeros"] / stats["count"] > 0.5:
                col_issues.append("high_zeros")

        if col_issues:
            issues[col] = col_issues

    return issues