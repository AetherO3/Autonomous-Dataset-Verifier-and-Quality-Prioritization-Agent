import pandas as pd
import os
import creds

file = "data/Tester.jsonl"

if os.path.exists(file):
    print("Yeah a path exists")

if os.path.isfile(file):
    print("Yes the path inculdes the file")

print("Trying to read the jsonl")

df = pd.read_json(file, lines=True)

print("Read the jsonl")

print(df.head())
print(df.shape)
print(creds.gemini_key)

df = pd.read_csv("data/amazon.csv")
print(df.shape)